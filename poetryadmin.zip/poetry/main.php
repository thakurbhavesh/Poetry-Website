<div class="mb-3">
   
    <h3 class="fw-bold fs-4 my-3">Show Poetry</h3>
    <div class="row">
        <div class="col-12">
            <table id="poetryTable" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
        $sql = "SELECT id, title, content, author FROM poetry where author='$username'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $count = 1;  // Start count at 1
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $count . "</td>";  // Display count
                echo "<td>" . $row["title"] . "</td>";
                echo "<td>" . $row["author"] . "</td>";
               
                echo "</tr>";
                $count++;  // Increment count after every row
            }
        } else {
            echo "<tr><td colspan='4'>No poetry records found.</td></tr>";
        }
        ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</main>