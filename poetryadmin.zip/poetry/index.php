<?php
// Start session at the top before any HTML
session_start();
// print_r($_SESSION);
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit(); // Always exit after header redirect
}
?>

<!-- Now include your header after session start -->
<?php include 'includes/header.php'; ?>


<?php include 'main.php'; ?>
<?php include 'includes/footer.php'; ?>
