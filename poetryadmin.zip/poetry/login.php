<?php
// Start session at the very top, before any HTML or output
session_start();

// Include database connection
include_once('includes/db.php');

// Initialize message variable
$message = '';

// Check for form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute the SQL query
    $sql = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Check password
        if (password_verify($password, $user['password'])) {
            // Store user session data
            $_SESSION['username'] = $user['username'];

            // Redirect to welcome page
            header('Location: index.php');
            exit(); // Always use exit() after header()
        } else {
            $message = "<div class='alert alert-warning'>Incorrect password.</div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>No user found with this email.</div>";
    }

    $stmt->close();
}
$conn->close();
?>

<style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
        }
        .button-group {
            display: flex;
            justify-content: space-between;
        }
    </style>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <h2>Login</h2>
        <?php if (!empty($message)) echo $message; ?>
        <form method="post" action="login.php">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="button-group">
                <button type="submit" class="btn btn-success">Login</button>
                <a href="register.php" class="btn btn-primary">Register Here</a>
            </div>
        </form>
    </div>

    <?php include 'includes/footer.php'; ?>

