<?php include 'includes/header.php'; 

$id = intval($_GET['id']);
$sql = "SELECT * FROM poetry WHERE id = $id";
$result = $conn->query($sql);
?>
<div class="container mt-5">
    <h2>View Poetry</h2>
    <?php if ($result->num_rows > 0): ?>
        <?php $row = $result->fetch_assoc(); ?>
        <h3><b><?php echo htmlspecialchars($row['title']); ?></b></h3>
        <p><?php echo html_entity_decode($row['content']); ?></p>
        <p><strong>Author:</strong> <?php echo htmlspecialchars($row['author']); ?></p>
    <?php else: ?>
        <p>No poetry found.</p>
    <?php endif; ?>
    <a href="display_poetry.php" class="btn btn-primary">Back to List</a>
</div>


<?php include 'includes/footer.php'; ?>
