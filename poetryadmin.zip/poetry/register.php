<?php include 'includes/header.php'; ?>
<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert alert-success'>Registration successful! You can now <a href='login.php'>login</a>.</div>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>
<style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
        }
        .button-group {
            display: flex;
            justify-content: space-between;
        }
    </style>

<div class="container mt-5">
    <h2>Register</h2>
    <form method="post" action="register.php">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="button-group">
            <button type="submit" class="btn btn-success">Register</button>
            <a href="login.php" class="btn btn-primary">Login Here</a>
        </div>
    </form>
</div>


<?php include 'includes/footer.php'; ?>