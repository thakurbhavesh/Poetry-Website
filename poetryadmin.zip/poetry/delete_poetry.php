<?php
 include 'includes/header.php'; 

 ob_start();
// Check if the ID parameter exists in the URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Prepare the DELETE statement
    $sql = "DELETE FROM poetry WHERE id = $id";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Redirect back to the poetry list page with a success message
        header('Location: display_poetry.php?message=Poetry+Deleted+Successfully');
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}

$conn->close();

// Flush (send) the output buffer and turn off output buffering
ob_end_flush();
?>
