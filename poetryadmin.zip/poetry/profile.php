<?php
// Start session at the very top, before any HTML or output
session_start();

// Include database connection
include_once('includes/db.php');

// Redirect to login if user is not logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit(); // Always use exit() after header()
}

// Initialize message variable
$message = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];

        // Fetch current password from the database
        $sql = "SELECT password FROM users WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $_SESSION['username']);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if (password_verify($current_password, $user['password'])) {
            // Update password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET password=? WHERE username=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ss', $hashed_password, $_SESSION['username']);

            if ($stmt->execute()) {
                $message = "<div class='alert alert-success'>Password updated successfully.</div>";
            } else {
                $message = "<div class='alert alert-danger'>Error updating password.</div>";
            }
        } else {
            $message = "<div class='alert alert-danger'>Current password is incorrect.</div>";
        }

        $stmt->close();
    } elseif (isset($_POST['update_bio'])) {
        $bio = $_POST['bio'];

        // Update bio
        $sql = "UPDATE users SET bio=? WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $bio, $_SESSION['username']);

        if ($stmt->execute()) {
            $message = "<div class='alert alert-success'>Bio updated successfully.</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error updating bio.</div>";
        }

        $stmt->close();
    }
}

// Fetch current user details
$sql = "SELECT * FROM users WHERE username=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- CKEditor -->
    <script src="https://cdn.ckeditor.com/4.20.1/standard/ckeditor.js"></script>
    <style>
        .profile-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #f8f9fa;
        }
        .form-control:disabled {
            background-color: #e9ecef;
        }
        .form-label {
            font-weight: bold;
        }
    </style>
</head>
<body>

    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row">
            <!-- Profile Details -->
            <div class="col-md-6 profile-card">
                <h3>Profile Details</h3>
                <?php if (!empty($message)) echo $message; ?>
                
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                </div>
            </div>

            <!-- Update Password Form -->
            <div class="col-md-6 profile-card">
                <h3>Update Password</h3>
                <form method="post" action="profile.php">
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Current Password</label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <button type="submit" name="update_password" class="btn btn-primary">Update Password</button>
                </form>
            </div>
        </div>

        <div class="row mt-4">
            <!-- Update Bio Form -->
            <div class="col-md-12 profile-card">
                <h3>Update Bio</h3>
                <form method="post" action="profile.php">
                    <div class="form-group">
                        <label for="bio" class="form-label">Author Bio:</label>
                        <textarea class="form-control" id="bio" name="bio" rows="10"><?php echo htmlspecialchars($user['bio']); ?></textarea>
                        <script>
                            CKEDITOR.replace('bio');
                        </script>
                    </div>
                    <button type="submit" name="update_bio" class="btn btn-primary">Update Bio</button>
                </form>
            </div>
        </div>

        <div class="d-flex justify-content-end mt-3">
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

</body>
</html>
