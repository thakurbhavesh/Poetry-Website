<?php 
ob_start();
session_start();
include 'includes/header.php'; 

$id = intval($_GET['id']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $author = $conn->real_escape_string($_POST['author']);

    $sql = "UPDATE poetry SET title='$title', content='$content', author='$author' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        $message = "Poetry updated successfully";
        header('Location: display_poetry.php');
        exit();
    } else {
        $message = "Error: " . $conn->error;
    }
}

$sql = "SELECT * FROM poetry WHERE id = $id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$conn->close();
?>


<div class="container mt-5">
    <h2>Edit Poetry</h2>
    <?php if (isset($message)): ?>
        <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>
    <form method="post" action="">
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($row['title']); ?>" required>
        </div>
        <div class="form-group">
            <label for="content">Content:</label>
            <textarea class="form-control" id="content" name="content" rows="10" required><?php echo htmlspecialchars($row['content']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="author">Author:</label>
            <input type="text" class="form-control" id="author" name="author" value="<?php echo htmlspecialchars($row['author']); ?>" readonly> 
        </div>
        <button type="submit" class="btn btn-primary mt-2">Update</button>
    </form>
</div>

<!-- Initialize CKEditor -->
<script>
    CKEDITOR.replace('content');
</script>

<?php 
ob_end_flush();
include 'includes/footer.php'; ?>
