<?php 
session_start();
include 'includes/header.php'; 


$sql = "SELECT id, title, content, author FROM poetry where author='$username'";
$result = $conn->query($sql);

$conn->close();
?>

<div class="container-fluid mt-5">
<?php if (isset($_GET['message'])): ?>
    <div class="alert alert-success mt-3">
        <?php echo htmlspecialchars($_GET['message']); ?>
    </div>
<?php endif; ?>
    <h2 class="text-center">Poetry Records</h2>
    <table id="poetryTable" class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <!-- <th>Content</th> -->
            <th>Author</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            $count = 1;  // Start count at 1
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $count . "</td>";  // Display count
                echo "<td>" . $row["title"] . "</td>";
                // echo "<td>" . $row["content"] . "</td>";
                echo "<td>" . $row["author"] . "</td>";
                echo "<td>
                            <button class='btn btn-info btn-sm view-btn' data-id='" . $row["id"] . "'>View</button>
                            <button class='btn btn-warning btn-sm edit-btn' data-id='" . $row["id"] . "'>Edit</button>
                            <a href='delete_poetry.php?id=" . $row["id"] . "' class='btn btn-danger btn-sm delete-btn' onclick='return confirm(\"Are you sure you want to delete this poetry?\")'>Delete</a>
                        </td>";
                echo "</tr>";
                $count++;  // Increment count after every row
            }
        } else {
            echo "<tr><td colspan='4'>No poetry records found.</td></tr>";
        }
        ?>
    </tbody>
</table>

</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function() {
    $('#poetryTable').DataTable();

    // View button click handler
    $('.view-btn').on('click', function() {
        var id = $(this).data('id');
        window.location.href = 'view_poetry.php?id=' + id;
    });

    // Edit button click handler
    $('.edit-btn').on('click', function() {
        var id = $(this).data('id');
        window.location.href = 'edit_poetry.php?id=' + id;
    });

    // Delete button click handler
    $('.delete-btn').on('click', function() {
        var id = $(this).data('id');
        if (confirm('Are you sure you want to delete this poetry?')) {
            window.location.href = 'delete_poetry.php?id=' + id;
        }
    });
});
</script>



<?php include 'includes/footer.php'; ?>