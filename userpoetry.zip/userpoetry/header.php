<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bhavesh Style Poetry Display</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <style>
    body {
        background-color: #f8f9fa;
        font-family: 'Noto Nastaliq Urdu', serif;
    }

    .poetry-card {
        background-color: #ffffff;
        border: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
        padding: 20px;
        border-radius: 8px;
    }

    .poetry-title {
        font-size: 1.5rem;
        font-weight: bold;
        text-align: center;
        margin-bottom: 10px;
        color: #343a40;
    }
    
    .poetry-author {
        font-size: 1.0rem;
        font-weight: bold;
        text-align: center;
        color: blueviolet;
    }

    .poetry-content {
        font-size: 1.25rem;
        text-align: center;
        line-height: 1.5;
        color: #495057;
        border-radius: 50%;
    }

    .navbar {
        background-color: #343a40;
    }

    .navbar-brand {
        font-size: 1.75rem;
        color: white !important;
    }

    .nav-link {
        color: white !important;
        margin-right: 15px;
    }

    footer {
        margin-top: 15px;
        background-color: #343a40;
        color: white;
        text-align: center;
        padding: 15px 0;
        /* position: fixed; */
        /* bottom: 0; */
        width: 100%;
    }
    </style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Bhavesh Poetry</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="poet.php">Poet</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li> -->
                </ul>
            </div>
        </div>
    </nav>
