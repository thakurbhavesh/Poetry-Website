<?php
include 'db.php';

// Fetch all poetry from the database
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>

<?php
include_once("header.php");
?>


    <div class="container mt-4 mb-4">
        <h2 class="text-center mb-4">Featured Poet</h2>

        <table id="poetryTable" class="display table table-striped">
            <thead>
                <tr>
                    <th>Author</th>
                    <th>Short Bio</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><a href="index.php?author=<?php echo htmlspecialchars($row['username']); ?>"><?php echo htmlspecialchars($row['username']); ?></a></td>
                        <td><?php echo html_entity_decode($row['bio']); ?></td>
                       
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                <tr>
                    <td colspan="3" class="text-center">No poetry found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php $conn->close(); ?>
    </div>

  
<?php include_once("footer.php");?>