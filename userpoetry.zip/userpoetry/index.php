<?php
include 'db.php';

// Fetch all poetry from the database
if(isset($_GET['author'])){
    $sql = "SELECT id, title, content,author FROM poetry where author='{$_GET['author']}'order by id desc";
}else{
   $sql = "SELECT id, title, content,author FROM poetry order by id desc";

}
$result = $conn->query($sql);
?>
<?php include_once('header.php');?>


<div class="container mt-4 mb-4">
    <h2 class="text-center mb-4">Featured Poetry</h2>

    <div class="row">
        <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
        <div class="col-md-6 offset-md-3">
            <div class="poetry-card">
                <div class="poetry-title"><?php echo htmlspecialchars($row['title']); ?></div>
                <div class="poetry-content"><?php echo $row['content']; ?></div>
                <div class="poetry-author"><?php echo htmlspecialchars($row['author']); ?></div>

            </div>

        </div>
        <?php endwhile; ?>
        <?php else: ?>
        <p class="text-center">No poetry found.</p>
        <?php endif; ?>

        <?php $conn->close(); ?>
    </div>
</div>
<?php
   include_once('footer.php');
   ?>